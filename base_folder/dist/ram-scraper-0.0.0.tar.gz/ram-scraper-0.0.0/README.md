# Ram Scraper
### Scrapes RAM module and spot prices off DRAMEXCHANGE website every 24 hours. Places data in a csv file

